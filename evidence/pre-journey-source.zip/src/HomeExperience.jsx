import React, {useState,useRef,useEffect} from 'react';
import {ArrowUpRight, ArrowRight, ArrowDown, ChevronLeft, ChevronRight, Mountain, Tent, Wrench, Plus, X, Maximize2} from 'lucide-react';
import {P, inquiry} from './routes.js';

function Media({file,alt,eager=false,className='',sizes='(max-width: 700px) 100vw, 60vw'}) {
  const stem=file.replace(/\.[^.]+$/,'');
  return <img className={className} src={`/images/${stem}-1000.webp`} srcSet={`/images/${stem}-640.webp 640w, /images/${stem}-1000.webp 1000w, /images/${stem}-1600.webp 1600w`} sizes={sizes} alt={alt} width="1600" height="1000" loading={eager?'eager':'lazy'} fetchPriority={eager?'high':'auto'}/>;
}
function Action({href,children,secondary=false}) {return <a className={`exp-action ${secondary?'exp-action-secondary':''}`} href={href}><span>{children}</span><ArrowUpRight size={23} aria-hidden="true"/></a>}
const destinations=[
  {title:'Take the long way.',label:'Overland',file:'hero.png',alt:'Next Jump flatbed truck on a forest trail',to:P.flatbeds+'#overlanding',Icon:Mountain,text:'Room for the gear. Freedom to keep going.'},
  {title:'Stay a little longer.',label:'Camper',file:'camper.jpg',alt:'Alaskan camper mounted on a Next Jump flatbed',to:P.camper,Icon:Tent,text:'Build the platform for your kind of basecamp.'},
  {title:'Make room for work.',label:'Work & business',file:'work.png',alt:'Ford pickups with Next Jump flatbeds',to:P.work,Icon:Wrench,text:'The load, the tools, the way you work.'}
];
const buildViews=[
  {title:'The whole idea.',file:'ute-front.jpg',alt:'Front view of the Super Ute Ford F-250 on a forest road',text:'A flatbed, side boxes, and a tailgate. The foundation of the Super Ute collaboration.'},
  {title:'Built from the details.',file:'ute-detail.jpg',alt:'Rear view of the Super Ute with its tailgate lowered between side storage boxes in the workshop',text:'The tailgate, open. A closer look at the Super Ute’s flatbed and side-box arrangement.'},
  {title:'When the road ends.',file:'ute-tent.jpg',alt:'The Super Ute with its rooftop camp setup deployed',text:'See how the complete camp setup comes together. Equipment shown is specific to this build.'}
];
function BuildGallery(){
  const [active,setActive]=useState(0);
  const [open,setOpen]=useState(false);
  const dialog=useRef(null);
  useEffect(()=>{if(!open)return;const opener=document.activeElement;const overflow=document.body.style.overflow;dialog.current.showModal();document.body.style.overflow='hidden';return()=>{document.body.style.overflow=overflow;opener?.focus()}},[open]);
  const move=(n)=>setActive((n+buildViews.length)%buildViews.length);
  return <section className="exp-builds" data-scene>
    <div className="container exp-section-head" data-reveal><div><span className="eyebrow">Made real at Next Jump</span><h2>Ideas are good.<br/><em>This is better.</em></h2></div><p>A closer look at the Super Ute.<br/>One truck. A lot of possibility.</p></div>
    <div className="exp-photo-fan" role="group" aria-label="Explore the Super Ute photos" onKeyDown={e=>{if(e.key==='ArrowRight'){e.preventDefault();move(active+1)}if(e.key==='ArrowLeft'){e.preventDefault();move(active-1)}}}>
      {buildViews.map((view,i)=>{const offset=(i-active+3)%3;return <button type="button" key={view.file} className={`exp-fan-photo ${offset===0?'is-active':offset===1?'is-next':'is-previous'}`} aria-label={`${i===active?'Enlarge':'Show'} ${view.title}`} aria-pressed={i===active} onClick={()=>i===active?setOpen(true):setActive(i)}><Media file={view.file} alt={view.alt}/><span aria-hidden="true">{i+1} / 3 {i===active?<Maximize2/>:<ArrowUpRight/>}</span></button>})}
    </div>
    <div className="container exp-gallery-bottom"><div className="exp-gallery-caption" aria-live="polite" aria-atomic="true"><h3>{buildViews[active].title}</h3><p>{buildViews[active].text}</p></div><div className="exp-gallery-controls"><button type="button" className="exp-round" aria-label="Previous build photo" onClick={()=>move(active-1)}><ChevronLeft/></button><span>{String(active+1).padStart(2,'0')} / 03</span><button type="button" className="exp-round" aria-label="Next build photo" onClick={()=>move(active+1)}><ChevronRight/></button></div><Action href={P.ute}>Explore the build</Action></div>
    {open&&<dialog ref={dialog} className="exp-photo-modal" aria-label="Super Ute full-size photo" onCancel={event=>{event.preventDefault();setOpen(false)}} onKeyDown={e=>{if(e.key==='ArrowRight'){e.preventDefault();move(active+1)}if(e.key==='ArrowLeft'){e.preventDefault();move(active-1)}}}><div className="exp-modal-head"><span>Super Ute / {active+1} of 3</span><button type="button" className="exp-round" aria-label="Close full-size photo" onClick={()=>setOpen(false)}><X/></button></div><Media file={buildViews[active].file} alt={buildViews[active].alt} sizes="100vw"/><div className="exp-modal-bottom"><button type="button" className="exp-round" aria-label="Previous full-size photo" onClick={()=>move(active-1)}><ChevronLeft/></button><p>{buildViews[active].text}</p><button type="button" className="exp-round" aria-label="Next full-size photo" onClick={()=>move(active+1)}><ChevronRight/></button></div></dialog>}
  </section>
}

export default function HomeExperience(){
  return <div className="expressive-home">
    <section className="exp-hero" data-scene aria-labelledby="home-headline">
      <div className="exp-hero-landscape"><Media file="hero.png" alt="Next Jump Ford F-350 flatbed on a wooded trail" eager sizes="100vw"/></div>
      <div className="exp-hero-shade" aria-hidden="true"/>
      <div className="exp-hero-copy"><p className="exp-location">Tacoma, Washington <span>Built for what’s next.</span></p><h1 id="home-headline"><span>Your truck.</span><span>Your next</span><em>chapter.</em></h1><p className="exp-hero-description">Aluminum flatbeds. Thoughtful upgrades.<br/>More room for the life you want to live.</p><div className="exp-hero-actions"><Action href={P.builder}>Build your flatbed</Action><a href={P.services} className="exp-hero-secondary">Explore installation <ArrowUpRight size={21}/></a></div></div>
      <a href={P.flatbeds} className="exp-hero-stamp"><span>Modular.<br/>Aluminum.<br/>Yours.</span><ArrowUpRight aria-hidden="true" size={30}/></a>
      <div className="exp-hero-bottom"><a href="#possibilities">Find your next chapter <ArrowDown size={19}/></a><span>Real Next Jump build. Optional equipment shown.</span></div>
    </section>

    <div className="exp-orange-bridge" aria-label="Built around your truck"><span>Less ordinary.</span><span className="exp-bridge-mark" aria-hidden="true">↗</span><span>More possibility.</span></div>

    <section id="possibilities" className="exp-destinations container">
      <div className="exp-section-head" data-reveal><div><span className="eyebrow">Make room for what moves you</span><h2>Where to <em>next?</em></h2></div><p>The same starting point.<br/>An entirely different adventure.</p></div>
      <div className="exp-destination-grid">{destinations.map(({title,label,file,alt,to,Icon,text},i)=><a key={to} href={to} className={`exp-destination exp-destination-${i}`} data-reveal><div className="exp-destination-image"><Media file={file} alt={alt}/><span className="exp-destination-icon"><Icon size={26}/></span><span className="exp-card-arrow"><ArrowUpRight size={30}/></span></div><div className="exp-destination-copy"><span>{label}</span><h3>{title}</h3><p>{text}</p></div></a>)}</div>
    </section>

    <section className="exp-platform" data-scene><div className="exp-contour" aria-hidden="true"/><div className="container exp-platform-grid"><div className="exp-platform-copy" data-reveal><span className="eyebrow">A different starting point</span><h2>One platform.<br/><em>All you.</em></h2><p>Replace the factory bed with a foundation you can make your own. Storage, sides, camp gear—or room to keep it simple.</p><Action href={P.flatbeds}>Explore the flatbed system</Action></div><a className="exp-platform-art" href={P.flatbeds+'#system'} aria-label="Explore flatbed components"><div className="exp-platform-disc" aria-hidden="true"/><div className="exp-platform-outline" aria-hidden="true"/><Media file="base-2.jpg" alt="Next Jump aluminum flatbed with removable sides"/><span className="exp-component-label"><Plus size={20}/> See what goes into it</span><span className="exp-platform-serial" aria-hidden="true">NJO / MODULAR</span></a></div><div className="container exp-platform-steps" data-reveal><div><strong>01</strong><span>Start with your truck.</span></div><div><strong>02</strong><span>Add what earns its place.</span></div><div><strong>03</strong><span>Plan it with our team.</span></div></div></section>

    <BuildGallery/>

    <section className="exp-shop container"><div className="exp-shop-images" data-reveal><div className="exp-shop-main"><Media file="install.jpg" alt="Installation work at the Next Jump shop"/></div><div className="exp-shop-secondary"><Media file="shop.png" alt="Next Jump Outfitters Tacoma shop"/></div><div className="exp-shop-tag">Built around<br/><strong>the whole truck.</strong></div></div><div className="exp-shop-copy" data-reveal><span className="eyebrow">Beyond the flatbed</span><h2>Bring the idea.<br/><em>Let’s build it.</em></h2><p>Suspension. Power. Lighting. The details that make a truck work for you, installed at our Tacoma shop.</p><div className="exp-service-links"><a href={P.services}>Explore installation <ArrowUpRight/></a><a href={P.about}>Meet Next Jump <ArrowUpRight/></a></div></div></section>

    <section className="exp-final"><div className="container"><div data-reveal><span className="eyebrow">Your next chapter starts here</span><h2>Dream it.<br/><span>Drive it.</span></h2></div><div className="exp-final-action" data-reveal><p>You don’t need a parts list.<br/>Just a truck and an idea.</p><Action href={inquiry()} secondary>Let’s talk about your build</Action><a href={P.builder} className="exp-final-link">Or start your configuration <ArrowRight size={20}/></a></div></div><ArrowUpRight className="exp-final-graphic" aria-hidden="true"/></section>
  </div>
}
